var helvetica = {
  src: '/skin/fonts/sifr-helveticacondensedroman.swf'
};
sIFR.activate(helvetica);


